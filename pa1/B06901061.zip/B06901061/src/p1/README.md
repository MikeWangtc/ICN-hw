### P1-Bonus

Modulo Operation

```python
# Usage: <dividend> % <divisor>
```

Power

```python
# Usage: <base> ^ <exponent>
```

